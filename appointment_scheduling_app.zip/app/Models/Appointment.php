<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
    use HasFactory;

    protected $fillable = [
        'first_name',
        'last_name',
        'alias',
        'slug',
        'site_id',
        'trainer_id',
        'date',
        'training_type_id',
        'time',
    ];
}
