<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Simple Email</title>
</head>

<body>
    <h2>Hello this is a Simple Email from <?php echo e($name); ?></h2>
</body>

</html>
<?php /**PATH E:\XAMPP\htdocs\appointment_scheduling_app\resources\views/emails/appointment-email.blade.php ENDPATH**/ ?>