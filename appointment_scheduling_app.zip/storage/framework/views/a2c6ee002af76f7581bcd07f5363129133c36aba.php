<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show text-white" role="alert">
        <span class="alert-text">
            <strong>
                <?php echo e(Session::get('success')); ?>

            </strong>
        </span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
        <span class="alert-text">
            <strong>
                <?php echo e(Session::get('error')); ?>

            </strong>
        </span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH E:\XAMPP\htdocs\appointment_scheduling_app\resources\views/errors/alerts.blade.php ENDPATH**/ ?>