<?php $__env->startSection('content'); ?>

<!--Begin::Sidebar-->
<?php echo $__env->make('dashboard.admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Begin::Sidebar-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\appointment_scheduling_app\resources\views/dashboard/admin/index.blade.php ENDPATH**/ ?>