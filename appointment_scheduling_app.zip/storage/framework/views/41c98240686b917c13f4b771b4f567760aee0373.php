<main class="main-content  mt-0">
    <div class="page-header align-items-start min-vh-100">
        <div class="container my-auto">
            <div class="row">
                <div class="col-lg-10 col-md-10 col-12 mx-auto">
                    <!--Begin::Alerts-->
                    <div class="mt-5 mb-5">
                        <?php echo $__env->make('errors.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <!--End::Alerts-->
                    <div class="card z-index-0 fadeIn3 fadeInBottom">
                        <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                            <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                                <h6 class="text-white text-capitalize ps-3">
                                    IAD Central's RDWF Training Scheduling Tool
                                </h6>
                            </div>
                        </div>
                        <div class="card-body px-0 pb-2">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th
                                                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                #
                                            </th>
                                            <th
                                                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                Site
                                            </th>
                                            <th
                                                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                Trainers
                                            </th>
                                            <th
                                                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                View Trainers
                                            </th>
                                            <th
                                                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                Appointment
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($sites): ?>
                                            <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="align-middle">
                                                        <div class="d-flex px-2 py-1">
                                                            <div class="d-flex flex-column justify-content-center">
                                                                <h6 class="mb-0 text-sm">
                                                                    <?php echo e($loop->iteration); ?>

                                                                </h6>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="align-middle">
                                                        <div class="d-flex px-2 py-1">
                                                            <div class="d-flex flex-column justify-content-center">
                                                                <h6 class="mb-0 text-sm">
                                                                    <strong>
                                                                        <?php echo e($site->code); ?>

                                                                    </strong>
                                                                </h6>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="align-middle">
                                                        <?php if($site = Site::Info($site->id)): ?>
                                                            <div class="d-flex px-2 py-1">
                                                                <div class="d-flex flex-column justify-content-center">
                                                                    <h6 class="mb-0 text-sm">
                                                                        <?php echo e($site->trainers->count()); ?> Trainers
                                                                    </h6>
                                                                    <?php if($site->trainers->count() > 0): ?>
                                                                        <p class="text-s text-dark mb-0">
                                                                            <?php $__currentLoopData = $site->trainers->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php echo e($trainer->name); ?> ,
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </p>
                                                                    <?php else: ?>
                                                                        <p class="text-s text-dark mb-0">
                                                                            No Trainers
                                                                        </p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        <?php else: ?>
                                                            <span class="badge badge-sm bg-gradient-danger">No
                                                                Trainer</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="align-middle">
                                                        <?php if($site->trainers->count() > 0): ?>
                                                            <button class="btn btn-sm btn-info"
                                                                wire:click='ViewTrainers("<?php echo e($site->id); ?>")'>
                                                                <span wire:loading
                                                                    wire:target='ViewTrainers("<?php echo e($site->id); ?>")'
                                                                    class="spinner-border spinner-border-sm"
                                                                    role="status" aria-hidden="true"></span>
                                                                View Trainers
                                                            </button>
                                                        <?php else: ?>
                                                            <span class="badge bg-gradient-danger">
                                                                No Trainers
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="align-middle">
                                                        <?php if($site->trainers->count() > 0): ?>
                                                            <button class="btn btn-sm btn-success"
                                                                wire:click='MakeAppointment("<?php echo e($site->id); ?>")'>
                                                                <span wire:loading
                                                                    wire:target='MakeAppointment("<?php echo e($site->id); ?>")'
                                                                    class="spinner-border spinner-border-sm"
                                                                    role="status" aria-hidden="true"></span>
                                                                Appointment
                                                            </button>
                                                        <?php else: ?>
                                                            <span class="badge bg-gradient-danger">
                                                                No Trainers
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td class="text-center" colspan="5">
                                                    <strong class="text-danger">
                                                        No Data Found
                                                    </strong>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php if($sites): ?>
                            <div class="card-footer">
                                <?php echo e($sites->render()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php /**PATH E:\XAMPP\htdocs\appointment_scheduling_app\resources\views/livewire/index.blade.php ENDPATH**/ ?>